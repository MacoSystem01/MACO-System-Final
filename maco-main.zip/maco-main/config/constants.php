<?php

return [
    'origenes' => [
        [
            'key' => 'N',
            'valor' => 'Nacional'
        ],
        [
            'key' => 'I',
            'valor' => 'Importado'
        ],
    ],

    'payments' => [
        [
            'key' => 'CR',
            'valor' => 'Crédito'
        ],
        [
            'key' => 'CO',
            'valor' => 'Contado'
        ],
    ],
];